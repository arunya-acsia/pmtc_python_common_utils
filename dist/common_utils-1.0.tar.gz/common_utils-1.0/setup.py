from setuptools import setup, find_packages

setup(
    name="common_utils",
    version="1.0",
    author="AutoSMACT",
    packages=find_packages()
)